// End-to-end smoke test in DRY_RUN mode (no Kling calls, no cost).
// Starts the server on a spare port, waits for inbox templates, uploads an avatar, places an order, waits for the result.
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { ROOT, loadEnv } from '../lib/env.mjs';

const PORT = 18790, BASE = `http://127.0.0.1:${PORT}`;
const env = loadEnv();
const H = { 'x-api-key': env.API_TOKEN || '' };
const srv = spawn(process.execPath, ['server.mjs'], { cwd: ROOT, env: { ...process.env, PORT: String(PORT), DRY_RUN: '1', EXPORT_PRORES: '0', PUBLIC_BASE_URL: BASE }, stdio: 'inherit' });
const sleep = ms => new Promise(r => setTimeout(r, ms));
const fail = m => { console.error('SMOKE FAIL:', m); srv.kill(); process.exit(1); };
try {
  for (let i = 0; i < 30; i++) { try { if ((await fetch(`${BASE}/health`)).ok) break; } catch {} await sleep(500); }
  let g;
  for (let i = 0; i < 60; i++) { g = await (await fetch(`${BASE}/api/gallery`, { headers: H })).json(); if (g.templates?.length) break; await sleep(2000); }
  if (!g.templates?.length) fail('no templates imported from media/inbox');
  console.log('gallery:', g.templates.map(t => `${t.id} ${t.width}x${t.height} ${t.duration}s layer=${t.layer}`).join(' | '));
  const img = fs.readdirSync(path.join(ROOT, 'examples')).find(f => /\.(jpg|png)$/i.test(f));
  const avatarBytes = img ? fs.readFileSync(path.join(ROOT, 'examples', img)) : Buffer.from('ffd8ffd9', 'hex');
  const a = await (await fetch(`${BASE}/api/avatars?name=Smoke`, { method: 'POST', headers: { ...H, 'Content-Type': 'image/jpeg' }, body: avatarBytes })).json();
  if (!a.id) fail('avatar upload: ' + JSON.stringify(a));
  const o = await (await fetch(`${BASE}/api/orders`, { method: 'POST', headers: { ...H, 'Content-Type': 'application/json' }, body: JSON.stringify({ templateId: g.templates[0].id, avatarId: a.id, mode: 'replace', supporterName: 'Smoke' }) })).json();
  if (!o.id) fail('order: ' + JSON.stringify(o));
  let s;
  for (let i = 0; i < 240; i++) { s = await (await fetch(`${BASE}/api/orders/${o.id}`, { headers: H })).json(); if (['succeeded', 'failed'].includes(s.status)) break; await sleep(1000); }
  if (s.status !== 'succeeded') fail('order status ' + s.status + ' ' + (s.error || ''));
  const head = await fetch(s.resultUrl, { method: 'HEAD' });
  if (!head.ok) fail('result not served: ' + head.status);
  if (env.DEFAULT_TRANSPARENT === '1') {
    if (!s.transparentUrl) fail('front package: order is not transparent by default');
    const th = await fetch(s.transparentUrl, { method: 'HEAD' });
    if (!th.ok) fail('transparent webm not served: ' + th.status);
    console.log('transparent:', s.transparentUrl);
  }
  const bad = await fetch(`${BASE}/api/gallery`);
  if (env.API_TOKEN && bad.status !== 401) fail('auth not enforced');
  console.log('SMOKE OK — order', o.id, '->', s.resultUrl);
} finally { srv.kill(); }
