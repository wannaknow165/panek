# WANNA Tribute Front: הוקרה לתומכים, שכבה קדמית שקופה

זו **חבילה נפרדת** לסרטוני **פרונט שקופים**, בעיקר להוקרה לתומכים. הדמות של התומך, עם האש והזוהר, מופיעה **מעל** המסך של המשדר בלייב, כמו מתנה של TikTok.

- זה אותו קוד ואותו מנוע (Kling 4.0) כמו בחבילת ה-background (`wanna-tribute-engine`). שתי החבילות רצות בנפרד, כל אחת על פורט משלה.
- **ברירת המחדל כאן היא שקוף** (`DEFAULT_TRANSPARENT=1`), והשכבה היא `front`.
- ההבדל בפועל: Kling מקבל, באותה קריאה, גם את ההחלפה או ההוספה וגם הוראה ל**רקע ירוק אחיד**. אחר כך השרת מוריד את הירוק ומוציא:
  - `.alpha.webm` (VP9 עם alpha), לנגן מעל הלייב (OBS, LIVE Studio או נגן דפדפן).
  - `.alpha.mov` (ProRes 4444 עם alpha), לעריכה.
  - `.mp4` המקורי עם הרקע הירוק, למקרה שרוצים להוריד את הירוק בצד השני.
- במהלך הלייב תומך חדש שולח אווטאר ותוך כמה דקות יש לו מתנה שקופה. אפשר גם להכין מראש, לפני הלייב.

---

## For the developer (English)

Everything in this package works the same way as in **wanna-tribute-engine**: same API, inbox, Kling client, and costs. Read that package's README for the full API reference. Below are only the differences.

| Setting | Front package (this one) | Background package |
|---|---|---|
| `PORT` | 8791 | 8790 |
| `DEFAULT_TRANSPARENT` | **1** (orders are transparent unless `"transparent": false`) | 0 |
| `DEFAULT_LAYER` | front | back |
| Kling prompt | replace/add **+ flat chroma-green background** | replace/add, scenery kept |
| Main output for the live | `transparentUrl` → `.alpha.webm` | `resultUrl` → `.mp4` |

### Quick start
```bash
# .env is included with live keys; set PUBLIC_BASE_URL to this server's public https address
npm start          # port 8791
npm test           # dry-run end-to-end, checks that the transparent WebM is produced and served
```

### Order (transparent by default)
```bash
curl -X POST "$BASE/api/orders" -H "x-api-key: $TOKEN" -H "Content-Type: application/json" \
  -d '{"templateId":"lion-knight","avatarId":"av_...","mode":"replace","supporterName":"Dani"}'
# → poll GET /api/orders/<id> (or use callbackUrl). Play transparentUrl (.alpha.webm) on top of the live.
```

### Tuning the overlay
- `TRANSPARENT_OPACITY` (default 0.92) sets the overall opacity of the overlay, so it blends with the stream.
- `PREVIEW_BACKGROUND=/path/to/live-frame.jpg` also produces `previewUrl`: the overlay composited on a live frame, for review.
- Keying is chromakey (key colour sampled from the frame corners) + despill. Glow and fire stay semi-transparent.
- The best templates for the front package have **one clear hero and few background objects**. Shots without the hero end up as an empty (fully transparent) frame. Use `trimStart`/`trimEnd` in the inbox sidecar to keep only the hero shots.

### Example
`examples/lion-knight__transparent-gift__on-live-preview.mp4` shows the approved transparent result over a live frame. `examples/lion-knight__transparent-gift__example.webm` is the alpha file itself.

### Security
`.env` contains **live keys**. Keep it out of git, and rotate the keys after the handover.
