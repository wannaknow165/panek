// WANNA Tribute Engine — "סרטוני הוקרה לתומכים"
// Backend: gallery of template videos + avatar upload + orders that put a supporter into a template (replace / add)
// using Kling 4.0 video editing. Zero npm dependencies (Node 20+), needs ffmpeg/ffprobe on PATH.
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { loadEnv, ROOT } from './lib/env.mjs';
import { Store } from './lib/store.mjs';
import { prepareTemplate } from './lib/media.mjs';
import { runOrder } from './lib/worker.mjs';
import { unitsLeft } from './lib/kling.mjs';

const env = loadEnv();
const PORT = Number(env.PORT || 8790);
const store = new Store(path.join(ROOT, 'data'));
const MEDIA = path.join(ROOT, 'media');
for (const d of ['templates', 'avatars', 'results', 'inbox', 'inbox/done', 'inbox/failed']) fs.mkdirSync(path.join(MEDIA, d), { recursive: true });

const json = (res, code, obj) => { res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Access-Control-Allow-Origin': '*' }); res.end(JSON.stringify(obj, null, 2)); };
const readBody = req => new Promise((ok, bad) => { const c = []; let n = 0; req.on('data', d => { n += d.length; if (n > 300 * 1024 * 1024) { bad(new Error('body too large')); req.destroy(); } else c.push(d); }); req.on('end', () => ok(Buffer.concat(c))); req.on('error', bad); });
const id = p => `${p}_${crypto.randomBytes(6).toString('hex')}`;
const publicUrl = rel => `${env.PUBLIC_BASE_URL.replace(/\/$/, '')}/media/${rel}`;
const authed = req => !env.API_TOKEN || req.headers['x-api-key'] === env.API_TOKEN;
const MIME = { '.mp4': 'video/mp4', '.webm': 'video/webm', '.mov': 'video/quicktime', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png', '.webp': 'image/webp' };

function serveMedia(req, res, rel) {
  const file = path.normalize(path.join(MEDIA, rel));
  if (!file.startsWith(MEDIA) || !fs.existsSync(file) || !fs.statSync(file).isFile()) return json(res, 404, { error: 'not found' });
  const size = fs.statSync(file).size; const type = MIME[path.extname(file).toLowerCase()] || 'application/octet-stream';
  const m = /bytes=(\d*)-(\d*)/.exec(req.headers.range || '');
  if (m) { const s = m[1] ? +m[1] : 0, e = m[2] ? +m[2] : size - 1; res.writeHead(206, { 'Content-Type': type, 'Content-Range': `bytes ${s}-${e}/${size}`, 'Accept-Ranges': 'bytes', 'Content-Length': e - s + 1 }); fs.createReadStream(file, { start: s, end: e }).pipe(res); }
  else { res.writeHead(200, { 'Content-Type': type, 'Content-Length': size, 'Accept-Ranges': 'bytes' }); fs.createReadStream(file).pipe(res); }
}

const templateView = t => ({ ...t, sampleUrl: publicUrl(t.file), examples: (t.examples || []).map(publicUrl) });
const orderView = o => ({ ...o, resultUrl: o.result ? publicUrl(o.result) : null, transparentUrl: o.transparent_result ? publicUrl(o.transparent_result) : null, previewUrl: o.preview ? publicUrl(o.preview) : null });

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    const p = url.pathname;
    if (req.method === 'OPTIONS') { res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': '*', 'Access-Control-Allow-Methods': 'GET,POST,DELETE' }); return res.end(); }
    if ((req.method === 'GET' || req.method === 'HEAD') && p.startsWith('/media/')) return serveMedia(req, res, decodeURIComponent(p.slice(7)));
    if (req.method === 'GET' && p === '/health') return json(res, 200, { ok: true, package: env.PACKAGE_NAME || 'background', defaultTransparent: env.DEFAULT_TRANSPARENT === '1', dryRun: env.DRY_RUN === '1', queue: store.pending().length });
    if (!authed(req)) return json(res, 401, { error: 'missing or wrong x-api-key' });

    // ---- Gallery ----
    if (req.method === 'GET' && p === '/api/gallery') return json(res, 200, { gallery: env.GALLERY_TITLE || 'סרטוני הוקרה לתומכים', templates: store.templates().filter(t => t.enabled !== false).map(templateView) });

    // Add a template video. Body = raw mp4 bytes. Query: id, title, trimStart, trimEnd (seconds, keep only the AI part), modes=replace,add, character (who to replace, English)
    if (req.method === 'POST' && p === '/api/templates') {
      const tid = (url.searchParams.get('id') || id('tpl')).replace(/[^a-z0-9_-]/gi, '-').toLowerCase();
      const raw = path.join(MEDIA, 'templates', `${tid}.upload.mp4`);
      fs.writeFileSync(raw, await readBody(req));
      const info = await prepareTemplate(raw, path.join(MEDIA, 'templates', `${tid}.mp4`), { trimStart: +url.searchParams.get('trimStart') || 0, trimEnd: +url.searchParams.get('trimEnd') || 0 });
      fs.unlinkSync(raw);
      const t = store.saveTemplate({ id: tid, title: url.searchParams.get('title') || tid, file: `templates/${tid}.mp4`, modes: (url.searchParams.get('modes') || 'replace,add').split(','), character: url.searchParams.get('character') || 'the main character', layer: url.searchParams.get('layer') || env.DEFAULT_LAYER || 'front', ...info, created: new Date().toISOString() });
      return json(res, 201, templateView(t));
    }
    if (req.method === 'DELETE' && p.startsWith('/api/templates/')) { store.saveTemplate({ ...store.template(p.split('/').pop()), enabled: false }); return json(res, 200, { ok: true }); }

    // ---- Avatars (upload before the live, or during the live when a new supporter sends one) ----
    // Body = raw image bytes (jpg/png/webp). Query: name (supporter name, optional)
    if (req.method === 'POST' && p === '/api/avatars') {
      const aid = id('av'); const ext = { 'image/png': '.png', 'image/webp': '.webp' }[req.headers['content-type']] || '.jpg';
      const file = `avatars/${aid}${ext}`; fs.writeFileSync(path.join(MEDIA, file), await readBody(req));
      const a = store.saveAvatar({ id: aid, name: url.searchParams.get('name') || '', file, created: new Date().toISOString() });
      return json(res, 201, { ...a, url: publicUrl(file) });
    }

    // ---- Orders ----
    // JSON: { templateId, avatarId, mode: "replace"|"add", supporterName, transparent: false, resolution: "1080p"|"720p", callbackUrl }
    if (req.method === 'POST' && p === '/api/orders') {
      const b = JSON.parse((await readBody(req)).toString() || '{}');
      const t = store.template(b.templateId), a = store.avatar(b.avatarId);
      if (!t) return json(res, 400, { error: 'unknown templateId' });
      if (!a) return json(res, 400, { error: 'unknown avatarId' });
      const mode = b.mode === 'add' ? 'add' : 'replace';
      if (!t.modes.includes(mode)) return json(res, 400, { error: `template does not allow mode ${mode}` });
      const o = store.saveOrder({ id: id('ord'), templateId: t.id, avatarId: a.id, mode, supporterName: b.supporterName || a.name || '', transparent: b.transparent === undefined ? env.DEFAULT_TRANSPARENT === '1' : !!b.transparent, resolution: b.resolution === '720p' ? '720p' : '1080p', callbackUrl: b.callbackUrl || null, status: 'queued', created: new Date().toISOString() });
      kick();
      return json(res, 202, orderView(o));
    }
    if (req.method === 'GET' && p.startsWith('/api/orders/')) { const o = store.order(p.split('/').pop()); return o ? json(res, 200, orderView(o)) : json(res, 404, { error: 'not found' }); }
    if (req.method === 'GET' && p === '/api/orders') return json(res, 200, store.orders().slice(-100).reverse().map(orderView));
    if (req.method === 'GET' && p === '/api/costs') return json(res, 200, store.costs());
    if (req.method === 'GET' && p === '/api/kling/units') return json(res, 200, await unitsLeft(env));
    return json(res, 404, { error: 'no route' });
  } catch (e) { console.error(e); json(res, 500, { error: String(e.message || e) }); }
});

// ---- Worker loop: up to KLING_CONCURRENCY orders at once ----
let running = 0;
function kick() {
  const max = Number(env.KLING_CONCURRENCY || 3);
  for (const o of store.pending()) {
    if (running >= max) return;
    if (o.status !== 'queued') continue;
    running++; store.saveOrder({ ...o, status: 'processing', started: new Date().toISOString() });
    runOrder({ order: store.order(o.id), store, env, MEDIA, publicUrl })
      .catch(e => { console.error('order', o.id, e); store.saveOrder({ ...store.order(o.id), status: 'failed', error: String(e.message || e), finished: new Date().toISOString() }); })
      .finally(async () => { running--; await notify(store.order(o.id)); kick(); });
  }
}
async function notify(o) {
  if (!o?.callbackUrl) return;
  try { await fetch(o.callbackUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(orderView(o)) }); } catch (e) { console.error('callback failed', o.id, e.message); }
}
// ---- Inbox: drop a video into media/inbox and it appears in the gallery automatically ----
// Optional sidecar <name>.json: { "title": "...", "trimStart": 0, "trimEnd": 14.6, "modes": ["replace","add"], "character": "the lion-headed warrior", "layer": "front"|"back", "order": 1 }
let scanning = false;
async function scanInbox() {
  if (scanning) return; scanning = true;
  const dir = path.join(MEDIA, 'inbox');
  try {
    for (const f of fs.readdirSync(dir)) {
      if (!/\.(mp4|mov)$/i.test(f)) continue;
      const src = path.join(dir, f);
      const s1 = fs.statSync(src).size; await new Promise(r => setTimeout(r, 2000)); if (fs.statSync(src).size !== s1) continue; // still copying
      const base = f.replace(/\.(mp4|mov)$/i, ''); const tid = base.replace(/[^a-z0-9_-]/gi, '-').toLowerCase();
      const sideFile = path.join(dir, `${base}.json`); const side = fs.existsSync(sideFile) ? JSON.parse(fs.readFileSync(sideFile, 'utf8')) : {};
      try {
        const info = await prepareTemplate(src, path.join(MEDIA, 'templates', `${tid}.mp4`), { trimStart: side.trimStart || 0, trimEnd: side.trimEnd || 0 });
        store.saveTemplate({ id: tid, title: side.title || base, file: `templates/${tid}.mp4`, modes: side.modes || ['replace', 'add'], character: side.character || 'the main character', layer: side.layer || env.DEFAULT_LAYER || 'front', order: side.order, prompts: side.prompts, ...info, created: new Date().toISOString() });
        fs.renameSync(src, path.join(dir, 'done', f)); if (fs.existsSync(sideFile)) fs.renameSync(sideFile, path.join(dir, 'done', `${base}.json`));
        console.log('inbox: imported', tid);
      } catch (e) {
        console.error('inbox: failed', f, e.message);
        fs.renameSync(src, path.join(dir, 'failed', f)); fs.writeFileSync(path.join(dir, 'failed', `${base}.error.txt`), String(e.message));
      }
    }
  } finally { scanning = false; }
}
setInterval(scanInbox, 10000); scanInbox();

// Resume orders interrupted by a restart
for (const o of store.orders()) if (o.status === 'processing') store.saveOrder({ ...o, status: 'queued' });

server.listen(PORT, () => { console.log(`WANNA Tribute Engine on :${PORT}  public=${env.PUBLIC_BASE_URL}  dryRun=${env.DRY_RUN === '1'}`); kick(); });
