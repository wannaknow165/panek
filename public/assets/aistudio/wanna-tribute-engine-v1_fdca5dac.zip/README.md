# WANNA Tribute Engine: סרטוני הוקרה לתומכים

זהו שרת backend של **פרונטים ללקוח**. משדר בוחר סרטון מגלריה, מעלה תמונה (אווטאר) של תומך, ומקבל את אותו סרטון אחד לאחד, כשהתומך **מחליף** את הדמות או **מצטרף** לידה. הסרטון מוכן לשידור ב-TikTok LIVE Studio.

- **במהלך הלייב:** נכנס תומך חדש ושולח אווטאר. מעלים את האווטאר ויוצרים הזמנה, ואחרי 5–10 דקות הסרטון מוכן.
- **לפני הלייב:** אפשר להעלות תמונות מראש ולהכין סרטונים מראש.
- **המנוע:** Kling 4.0, דרך API ישיר (Omni Video, עריכת וידאו עם תמונת רפרנס). זה המנוע היחיד שעבר את הבדיקות באיכות מלאה.
- **שקיפות:** ברירת המחדל היא **סרטון רגיל, לא שקוף**, וזה מה שמומלץ. אפשר לבקש גרסה שקופה: Kling מקבל הוראה לרקע ירוק, והשרת מוציא WebM עם alpha ו-ProRes 4444.

---

## For the developer (English)

### Requirements
- Node.js 20+ (no npm dependencies)
- `ffmpeg` and `ffprobe` on PATH (or set `FFMPEG` / `FFPROBE` env vars)
- **A public HTTPS address for this server.** Kling downloads the template video from `PUBLIC_BASE_URL/media/...`. If the server is not public, Kling cannot read the video.

### Run
```bash
cp .env.example .env   # .env with live keys is already included in this package
# set PUBLIC_BASE_URL=https://your-domain
npm start              # node server.mjs  (port 8790)
npm test               # dry-run end-to-end smoke test, no Kling cost
```

### Template videos (the gallery)
**Drop a video into `media/inbox/`. It appears in the gallery automatically within about 10 seconds.**
You can add an optional sidecar file with the same name, `<name>.json`:
```json
{ "title": "אביר האריה", "trimStart": 0, "trimEnd": 14.6, "modes": ["replace","add"],
  "character": "the lion-headed armored warrior", "layer": "front", "order": 1 }
```
- `trimStart` / `trimEnd` keep **only the AI part.** Source clips often end (or start) with the real streamer, and that part has to be cut off.
- `character` says, in English, who to replace or join (it goes into the Kling prompt).
- `layer` is `front` or `back`: how your effects/compositor layer should place the clip.
- On import, the server cuts to the AI range, removes black borders, upscales so the short side is at least 720 px (Kling needs 700 px or more), re-encodes to 30 fps H.264, and checks the 3–30 s length limit.
- Imported files move to `media/inbox/done/`. Failures move to `media/inbox/failed/` with an `.error.txt`.
- You can also upload over HTTP: `POST /api/templates?id=...&title=...&trimEnd=...&character=...&layer=front` with the raw mp4 as the body.

The package ships with two templates in the inbox: `lion-knight` (tested, see `examples/`) and `ice-queen`.

### API (header `x-api-key: <API_TOKEN>`; `/media/*` and `/health` are public)
| Method | Path | Body / query | Returns |
|---|---|---|---|
| GET | `/api/gallery` | | templates with `sampleUrl`, `duration`, `modes`, `layer` |
| POST | `/api/avatars?name=Supporter` | raw image bytes (`Content-Type: image/jpeg\|png\|webp`) | `{ id, url }` |
| POST | `/api/orders` | `{ templateId, avatarId, mode: "replace"\|"add", supporterName, transparent: false, resolution: "1080p"\|"720p", callbackUrl }` | order (202) |
| GET | `/api/orders/:id` | | `status`: `queued`→`processing`→`succeeded`\|`failed`, `resultUrl`, `transparentUrl` |
| GET | `/api/orders` | | last 100 orders |
| GET | `/api/costs` | | cost ledger (Kling units per order) |
| GET | `/api/kling/units` | | remaining Kling resource-pack units |
| POST | `/api/templates` | raw mp4 + query as above | template |
| DELETE | `/api/templates/:id` | | hides the template |

If `callbackUrl` is set, the server POSTs the final order JSON to it when the order succeeds or fails. Use this to push the clip into LIVE Studio without polling.

### Live flow example
```bash
A=$(curl -s -X POST "$BASE/api/avatars?name=Dani" -H "x-api-key: $TOKEN" -H "Content-Type: image/jpeg" --data-binary @dani.jpg | jq -r .id)
curl -s -X POST "$BASE/api/orders" -H "x-api-key: $TOKEN" -H "Content-Type: application/json" \
  -d "{\"templateId\":\"lion-knight\",\"avatarId\":\"$A\",\"mode\":\"replace\",\"supporterName\":\"Dani\"}"
# poll GET /api/orders/<id> or receive callbackUrl → play resultUrl on the live
```

### Costs and timing (measured 2026-11-11)
- Kling 4.0 with an input video bills (input + output) seconds: **0.9 units/s at 1080p, 0.6 units/s at 720p.** A 17 s template at 1080p costs about **30.7 units**, and a 12 s template about 21.6 units.
- About 5–6 minutes per order. Orders run in parallel (`KLING_CONCURRENCY`, default 3).
- The trial pack on this key is almost used up (about 2.7 units left). **A Kling API resource pack (for Kling 4.0) must be bought before production.** Check it with `GET /api/kling/units`.

### Engines tested (and why Kling)
| Engine | Result |
|---|---|
| **Kling 4.0 direct** | ✅ true 1:1 replacement, excellent identity, original audio |
| Kling v3 via OpenRouter | ⚠️ no video input; makes new scenes, not a replacement |
| Seedance 2.5 / 2.0 | ❌ rejects input video ("may contain real person") |
| Gemini Omni 1.1 / 1.2 | ❌ "Video generation failed" |
| FLUX Video Edit | ⚠️ cannot take the avatar; only useful to recolour a background green |
| Runway Aleph 2, Hailuo 3, Wan 2.6 | ❌ need an HTTPS link, 2K only, or no video input |

### Transparent option
`transparent: true` adds a "flat chroma green background" instruction to the same Kling call. The result is keyed (chromakey + despill + 92% opacity, set by `TRANSPARENT_OPACITY`) into `.alpha.webm` (VP9 alpha) and `.alpha.mov` (ProRes 4444). Set `PREVIEW_BACKGROUND=/path/live-frame.jpg` to also get a composited preview. **Default and recommended: not transparent.**

### Files
```
server.mjs          HTTP API, worker queue, inbox watcher
lib/kling.mjs       Kling 4.0 omni-video client + prompt builder (replace / add / green)
lib/worker.mjs      order execution, cost ledger, transparent export
lib/media.mjs       ffmpeg: template prep, chroma key, preview
lib/store.mjs       JSON store (data/db.json)
media/inbox         drop template videos here
media/templates     prepared templates (served at /media/templates/...)
media/avatars       uploaded avatars
media/results       finished videos
examples/           approved test outputs (replace, transparent gift, on-live preview)
test/smoke.mjs      dry-run end-to-end test
```

### Security
`.env` contains **live keys** (Kling, OpenRouter, and an API token). Keep it out of git, and rotate the keys after the handover.
